#SQL_ASSIGNMENT_QUARIES

USE superstores;

#Q_1
SELECT Customer_Name as "Customer Name" , Customer_Segment as "Customer Segment" FROM cust_dimen;

#Q_2
SELECT * FROM cust_dimen
ORDER BY Cust_id DESC;

#Q_3
SELECT Order_ID, Order_Date FROM orders_dimen
WHERE Order_Priority LIKE 'HIGH';

#Q_4
SELECT sum(Sales) as tota_sales, avg(Sales) as avg_sales FROM market_fact;

#Q_5
SELECT max(Sales) as max_sales, min(Sales) as min_sales FROM market_fact;

#Q_6
SELECT Region, COUNT(*) as 'no_of_customers' FROM cust_dimen
GROUP BY Region
ORDER BY no_of_customers DESC;

#Q_7
SELECT Region, COUNT(*) as 'max(no_of_customers)' FROM cust_dimen
GROUP BY Region
ORDER BY COUNT(*) DESC
LIMIT 1;

#Q_8
SELECT c.customer_name, COUNT(*) as no_of_tables_purchased 
FROM market_fact m INNER JOIN cust_dimen c ON m.Cust_id=c.Cust_id
WHERE c.Region='ATLANTIC'
AND m.Prod_id=(SELECT Prod_id FROM prod_dimen WHERE Product_Sub_Category LIKE 'TABLES')
GROUP BY m.Cust_id, c.Cust_id;

#Q_9
SELECT Customer_Name, COUNT(Customer_Segment) as no_of_small_business_owners FROM cust_dimen
WHERE Province LIKE 'ONTARIO' AND Customer_Segment LIKE 'SMALL BUSINESS'
GROUP BY Customer_Name;

#Q_10
SELECT Prod_id, COUNT(*) as no_of_products_sold FROM market_fact
GROUP BY Prod_id
ORDER BY no_of_products_sold DESC;

#Q_11
SELECT Prod_id, Product_Sub_Category FROM prod_dimen
WHERE Product_Category IN ('FURNITURE', 'TECHNOLOGY');

#Q_12
SELECT p.Product_Category as Product_Category, SUM(m.Profit) as Profit FROM market_fact m 
JOIN prod_dimen p ON m.Prod_id=p.Prod_id
GROUP BY Product_Category
ORDER BY SUM(m.Profit) DESC;

#Q_13
SELECT p.product_category as Product_Category, p.product_sub_category as Product_Sub_Category, SUM(m.profit) AS Profit
FROM market_fact m
INNER JOIN prod_dimen p ON m.prod_id = p.prod_id
GROUP BY p.product_sub_category;

#Q_14
SELECT o.Order_Date as Order_Date, m.Order_Quantity as Order_Quantity, SUM(m.sales) as Sales
FROM market_fact m
JOIN orders_dimen o ON m.Ord_id = o.Ord_id
GROUP BY Order_Date
ORDER BY Order_Quantity DESC;

#Q_15

#(i)
SELECT Customer_Name FROM cust_dimen 
WHERE Customer_Name LIKE'_R%'; 

#(ii)
SELECT Customer_Name FROM cust_dimen 
WHERE Customer_Name LIKE'___D%';

#Q_16
SELECT  c.Cust_id, c.customer_Name, c.Region, m.sales
FROM cust_dimen c, market_fact m
WHERE c.cust_id=m.cust_id 
AND m.sales BETWEEN 1000 AND 5000;

#Q_17
SELECT sales as '3_rd highest sale' 
FROM 
    (SELECT sales 
     FROM market_fact 
     ORDER BY sales DESC 
     LIMIT 1) as Top_Sale
ORDER BY sales 
LIMIT 3;

#Q_18
SELECT c.region, COUNT(distinct s.ship_id) AS no_of_shipments, SUM(m.profit) AS profit_in_each_region
FROM market_fact m
INNER JOIN cust_dimen c ON m.cust_id = c.cust_id
INNER JOIN shipping_dimen s ON m.ship_id = s.ship_id
INNER JOIN prod_dimen p ON m.prod_id = p.prod_id
WHERE p.product_sub_category IN 
(SELECT p.product_sub_category
FROM market_fact m
INNER JOIN
prod_dimen p ON m.prod_id = p.prod_id
GROUP BY p.product_sub_category
HAVING SUM(m.profit) <= ALL
(SELECT SUM(m.profit) AS profits
FROM market_fact m
INNER JOIN prod_dimen p ON m.prod_id = p.prod_id
GROUP BY p.product_sub_category))
GROUP BY c.region
ORDER BY profit_in_each_region DESC;