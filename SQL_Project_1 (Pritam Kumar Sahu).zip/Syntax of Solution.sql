#HR_DATABASE_EXERCISE

USE hr;

#1
SELECT first_name as FIRST_NAME, last_name as LAST_NAME FROM employees;

#2
SELECT DISTINCT department_id
FROM employees;

#3
SELECT * FROM employees order by first_name DESC;

#4
SELECT concat(first_name,", ",last_name), salary, salary * 0.15 as PF FROM employees;

#5
SELECT employee_id, concat(first_name,", ",last_name), salary FROM employees
ORDER BY salary ASC;

#6
SELECT sum(salary) from employees;

#7
SELECT max(salary), min(salary) from employees;

#8
SELECT avg(salary), count(*) from employees;

#9
SELECT count(*) FROM employees;

#10
SELECT count(job_id) FROM employees;

#11
SELECT UPPER(first_name) FROM employees;

#12
SELECT LEFT(first_name, 3) FROM employees;

#13
SELECT TRIM(first_name) FROM employees;

#14
SELECT LENGTH(CONCAT(first_name, last_name)) from employees;

#15
SELECT * FROM employees
WHERE first_name REGEXP '[0-9]';

#16
SELECT CONCAT(first_name, last_name), salary FROM employees
WHERE salary < 10000 OR salary > 15000;

#17
SELECT CONCAT(first_name, last_name), department_id FROM employees
WHERE department_id = 30 OR department_id = 100 
ORDER BY department_id ASC;

#18
SELECT CONCAT(first_name, last_name), salary FROM employees
WHERE (salary < 10000 OR salary > 15000) AND (department_id = 30 OR department_id = 100 );

#19
SELECT CONCAT(first_name, last_name), hire_date FROM employees
WHERE YEAR(hire_date) = 1987;

#20
SELECT first_name FROM employees
WHERE first_name LIKE '%b%'AND first_name LIKE '%c%';

#21
SELECT last_name, job_id, salary from employees
WHERE job_id IN ('IT_PROG', 'SH_CLERK')
AND salary NOT IN (4500, 10000, 15000);

#22
SELECT last_name FROM employees
WHERE length(last_name)=6;

#23
SELECT last_name FROM employees
WHERE last_name LIKE '__e%';

#24
SELECT job_id, group_concat(employee_id) AS Employee_id FROM employees
GROUP BY job_id;

#25
UPDATE employees
SET phone_number = REPLACE(phone_number,124,999)
WHERE phone_number LIKE '%124%';

#26
SELECT * FROM employees
WHERE length(first_name) >=8;

#27
UPDATE employees SET email = CONCAT(email, '@example.com');

#28
SELECT RIGHT(phone_number,4) AS Phone_Number FROM employees;

#29
SELECT street_address, SUBSTRING_INDEX(street_address,' ',-1) AS Last_Word_Of_Address FROM locations;

#30
SELECT location_id FROM locations
WHERE LENGTH(street_address) = (SELECT  MIN(LENGTH(street_address)) FROM locations);

#31
SELECT job_title, SUBSTR( job_title, 1, INSTR( job_title, ' ') -1) AS First_Word_Of_Job_Title FROM jobs;

#32
SELECT length(first_name) FROM employees
WHERE last_name LIKE '__c%';

#33
SELECT first_name AS First_Name, length(first_name) AS Length_Of_First_Name FROM employees
WHERE first_name LIKE 'A%'OR first_name LIKE 'J%' OR first_name LIKE 'M%'
ORDER BY first_name;

#34
SELECT first_name, LPAD(salary,10,'$') as SALARY FROM employees;

#35
SELECT LEFT(first_name,8), REPEAT('$', FLOOR(salary/1000)) AS SALARY_$, salary FROM employees
ORDER BY salary DESC;

#36
SELECT employee_id, first_name, last_name, hire_date FROM employees
WHERE DAY(hire_date) = 07 OR MONTH(hire_date) = 07;




#NORTHWIND_DATABASE_EXERCISE

Use northwind;

#1
SELECT ProductName, QuantityPerUnit FROM products;

#2
SELECT ProductId, ProductName FROM products
WHERE Discontinued = False;

#3
SELECT ProductId, ProductName FROM products
WHERE Discontinued = 1;

#4
SELECT ProductName, UnitPrice FROM products
ORDER BY UnitPrice DESC;

#5
SELECT ProductID, ProductName, UnitPrice FROM products
WHERE UnitPrice < 20 AND Discontinued = False;

#6
SELECT ProductID, ProductName, UnitPrice FROM products
WHERE UnitPrice > 15 AND UnitPrice < 25;

#7
SELECT ProductName, UnitPrice FROM products
WHERE UnitPrice > (SELECT avg(UnitPrice) FROM products);

#8
SELECT ProductName, UnitPrice FROM products
ORDER BY UnitPrice DESC
LIMIT 10;

#9
SELECT COUNT(ProductID) FROM products
GROUP BY Discontinued = False;

#10
SELECT ProductName, UnitsOnOrder, UnitsInStock FROM products
WHERE UnitsInStock < UnitsOnOrder;

